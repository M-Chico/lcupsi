file(REMOVE_RECURSE
  "CMakeFiles/upsi_okvs_adapter.dir/src/upsi_okvs_adapter.cpp.obj"
  "CMakeFiles/upsi_okvs_adapter.dir/src/upsi_okvs_adapter.cpp.obj.d"
  "libupsi_okvs_adapter.a"
  "libupsi_okvs_adapter.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_okvs_adapter.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
