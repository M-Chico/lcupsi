# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for upsi_okvs_adapter.
