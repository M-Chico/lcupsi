# Empty dependencies file for upsi_okvs_adapter.
# This may be replaced when dependencies are built.
