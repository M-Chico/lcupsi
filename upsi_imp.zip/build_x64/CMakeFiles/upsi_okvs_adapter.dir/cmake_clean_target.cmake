file(REMOVE_RECURSE
  "libupsi_okvs_adapter.a"
)
