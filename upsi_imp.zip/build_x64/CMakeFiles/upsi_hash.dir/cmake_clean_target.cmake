file(REMOVE_RECURSE
  "libupsi_hash.a"
)
