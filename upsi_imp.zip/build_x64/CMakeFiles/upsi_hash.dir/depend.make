# Empty dependencies file for upsi_hash.
# This may be replaced when dependencies are built.
