file(REMOVE_RECURSE
  "CMakeFiles/upsi_hash.dir/src/upsi_hash.cpp.obj"
  "CMakeFiles/upsi_hash.dir/src/upsi_hash.cpp.obj.d"
  "libupsi_hash.a"
  "libupsi_hash.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_hash.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
