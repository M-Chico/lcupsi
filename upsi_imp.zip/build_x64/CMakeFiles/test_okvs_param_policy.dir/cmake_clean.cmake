file(REMOVE_RECURSE
  "CMakeFiles/test_okvs_param_policy.dir/tests/test_okvs_param_policy.cpp.obj"
  "CMakeFiles/test_okvs_param_policy.dir/tests/test_okvs_param_policy.cpp.obj.d"
  "libtest_okvs_param_policy.dll.a"
  "test_okvs_param_policy.exe"
  "test_okvs_param_policy.exe.manifest"
  "test_okvs_param_policy.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_okvs_param_policy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
