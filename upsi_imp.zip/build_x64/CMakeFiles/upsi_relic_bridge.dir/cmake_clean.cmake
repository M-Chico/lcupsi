file(REMOVE_RECURSE
  "CMakeFiles/upsi_relic_bridge.dir/src/upsi_relic_bridge.c.obj"
  "CMakeFiles/upsi_relic_bridge.dir/src/upsi_relic_bridge.c.obj.d"
  "libupsi_relic_bridge.a"
  "libupsi_relic_bridge.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/upsi_relic_bridge.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
