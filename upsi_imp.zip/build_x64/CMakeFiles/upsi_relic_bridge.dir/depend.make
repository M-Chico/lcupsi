# Empty dependencies file for upsi_relic_bridge.
# This may be replaced when dependencies are built.
