file(REMOVE_RECURSE
  "libupsi_relic_bridge.a"
)
