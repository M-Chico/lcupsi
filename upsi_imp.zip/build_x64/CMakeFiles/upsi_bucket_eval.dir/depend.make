# Empty dependencies file for upsi_bucket_eval.
# This may be replaced when dependencies are built.
