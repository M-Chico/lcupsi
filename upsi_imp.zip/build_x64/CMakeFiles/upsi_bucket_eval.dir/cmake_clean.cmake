file(REMOVE_RECURSE
  "CMakeFiles/upsi_bucket_eval.dir/src/upsi_protocol_bucket_eval.cpp.obj"
  "CMakeFiles/upsi_bucket_eval.dir/src/upsi_protocol_bucket_eval.cpp.obj.d"
  "libupsi_bucket_eval.a"
  "libupsi_bucket_eval.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_bucket_eval.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
