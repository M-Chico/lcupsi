file(REMOVE_RECURSE
  "libupsi_bucket_eval.a"
)
