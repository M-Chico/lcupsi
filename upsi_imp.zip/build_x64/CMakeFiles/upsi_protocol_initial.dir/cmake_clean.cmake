file(REMOVE_RECURSE
  "CMakeFiles/upsi_protocol_initial.dir/src/upsi_protocol_initial.cpp.obj"
  "CMakeFiles/upsi_protocol_initial.dir/src/upsi_protocol_initial.cpp.obj.d"
  "libupsi_protocol_initial.a"
  "libupsi_protocol_initial.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_protocol_initial.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
