file(REMOVE_RECURSE
  "libupsi_protocol_initial.a"
)
