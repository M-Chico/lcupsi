# Empty dependencies file for upsi_protocol_initial.
# This may be replaced when dependencies are built.
