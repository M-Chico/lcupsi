file(REMOVE_RECURSE
  "CMakeFiles/test_okvs_small_n_calibration.dir/tests/test_okvs_small_n_calibration.cpp.obj"
  "CMakeFiles/test_okvs_small_n_calibration.dir/tests/test_okvs_small_n_calibration.cpp.obj.d"
  "libtest_okvs_small_n_calibration.dll.a"
  "test_okvs_small_n_calibration.exe"
  "test_okvs_small_n_calibration.exe.manifest"
  "test_okvs_small_n_calibration.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_okvs_small_n_calibration.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
