# Empty dependencies file for okvs.
# This may be replaced when dependencies are built.
