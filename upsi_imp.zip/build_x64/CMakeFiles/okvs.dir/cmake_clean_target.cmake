file(REMOVE_RECURSE
  "libokvs.a"
)
