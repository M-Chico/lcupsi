file(REMOVE_RECURSE
  "CMakeFiles/okvs.dir/third_party/okvs/src/bokvsv2.cpp.obj"
  "CMakeFiles/okvs.dir/third_party/okvs/src/bokvsv2.cpp.obj.d"
  "CMakeFiles/okvs.dir/third_party/okvs/src/galois128.cpp.obj"
  "CMakeFiles/okvs.dir/third_party/okvs/src/galois128.cpp.obj.d"
  "libokvs.a"
  "libokvs.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/okvs.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
