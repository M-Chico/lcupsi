# Empty compiler generated dependencies file for test_relic_bridge_consistency.
# This may be replaced when dependencies are built.
