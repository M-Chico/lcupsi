file(REMOVE_RECURSE
  "CMakeFiles/test_relic_bridge_consistency.dir/tests/test_relic_bridge_consistency.cpp.obj"
  "CMakeFiles/test_relic_bridge_consistency.dir/tests/test_relic_bridge_consistency.cpp.obj.d"
  "libtest_relic_bridge_consistency.dll.a"
  "test_relic_bridge_consistency.exe"
  "test_relic_bridge_consistency.exe.manifest"
  "test_relic_bridge_consistency.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_relic_bridge_consistency.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
