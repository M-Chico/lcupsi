file(REMOVE_RECURSE
  "CMakeFiles/test_bucketization.dir/tests/test_bucketization.cpp.obj"
  "CMakeFiles/test_bucketization.dir/tests/test_bucketization.cpp.obj.d"
  "libtest_bucketization.dll.a"
  "test_bucketization.exe"
  "test_bucketization.exe.manifest"
  "test_bucketization.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_bucketization.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
