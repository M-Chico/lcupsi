file(REMOVE_RECURSE
  "CMakeFiles/test_okvs_blocksplit.dir/tests/test_okvs_blocksplit.cpp.obj"
  "CMakeFiles/test_okvs_blocksplit.dir/tests/test_okvs_blocksplit.cpp.obj.d"
  "libtest_okvs_blocksplit.dll.a"
  "test_okvs_blocksplit.exe"
  "test_okvs_blocksplit.exe.manifest"
  "test_okvs_blocksplit.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_okvs_blocksplit.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
