file(REMOVE_RECURSE
  "CMakeFiles/test_pbpsi_m1.dir/tests/test_pbpsi_m1.c.obj"
  "CMakeFiles/test_pbpsi_m1.dir/tests/test_pbpsi_m1.c.obj.d"
  "libtest_pbpsi_m1.dll.a"
  "test_pbpsi_m1.exe"
  "test_pbpsi_m1.exe.manifest"
  "test_pbpsi_m1.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/test_pbpsi_m1.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
