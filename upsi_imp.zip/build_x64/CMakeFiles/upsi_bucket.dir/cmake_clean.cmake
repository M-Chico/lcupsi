file(REMOVE_RECURSE
  "CMakeFiles/upsi_bucket.dir/src/upsi_bucket.cpp.obj"
  "CMakeFiles/upsi_bucket.dir/src/upsi_bucket.cpp.obj.d"
  "libupsi_bucket.a"
  "libupsi_bucket.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_bucket.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
