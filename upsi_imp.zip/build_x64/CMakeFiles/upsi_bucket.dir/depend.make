# Empty dependencies file for upsi_bucket.
# This may be replaced when dependencies are built.
