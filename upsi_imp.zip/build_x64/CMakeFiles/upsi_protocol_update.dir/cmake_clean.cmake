file(REMOVE_RECURSE
  "CMakeFiles/upsi_protocol_update.dir/src/upsi_protocol_update.cpp.obj"
  "CMakeFiles/upsi_protocol_update.dir/src/upsi_protocol_update.cpp.obj.d"
  "libupsi_protocol_update.a"
  "libupsi_protocol_update.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/upsi_protocol_update.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
