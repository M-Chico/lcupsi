file(REMOVE_RECURSE
  "libupsi_protocol_update.a"
)
