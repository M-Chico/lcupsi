# Empty dependencies file for upsi_protocol_update.
# This may be replaced when dependencies are built.
