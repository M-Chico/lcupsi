# Empty dependencies file for test_delta_round_small.
# This may be replaced when dependencies are built.
