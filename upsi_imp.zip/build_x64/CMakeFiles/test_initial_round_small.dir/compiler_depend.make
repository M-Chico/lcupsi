# Empty compiler generated dependencies file for test_initial_round_small.
# This may be replaced when dependencies are built.
