file(REMOVE_RECURSE
  "CMakeFiles/test_initial_round_small.dir/tests/test_initial_round_small.cpp.obj"
  "CMakeFiles/test_initial_round_small.dir/tests/test_initial_round_small.cpp.obj.d"
  "libtest_initial_round_small.dll.a"
  "test_initial_round_small.exe"
  "test_initial_round_small.exe.manifest"
  "test_initial_round_small.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/test_initial_round_small.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
