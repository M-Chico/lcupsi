param(
  [ValidateSet("X86", "X64")]
  [string]$Arch = "X64",
  [int]$Cores = 1,
  [ValidateSet("AUTO", "NONE", "OPENMP", "PTHREAD")]
  [string]$MultiMode = "AUTO",
  [string]$ToolchainRoot = "C:\Users\chico\Documents\Codex\upsi\toolchains\winlibs-x64\mingw64",
  [switch]$CleanConfigure = $true
)

$ErrorActionPreference = "Stop"

$cmake = "cmake"
$repoCmake = "C:\Users\chico\Documents\Codex\upsi\alos22\tools\cmake-3.31.11-windows-x86_64\bin\cmake.exe"
if (Test-Path $repoCmake) {
  $cmake = $repoCmake
}

$relicRoot = "C:\Users\chico\Documents\Codex\upsi\alos22\relic-main"
$targetDir = Join-Path $relicRoot "demo\psi-client-server\target"

$binDir = Join-Path $ToolchainRoot "bin"
$cc = Join-Path $binDir "gcc.exe"
$cxx = Join-Path $binDir "g++.exe"
if (!(Test-Path $cc) -or !(Test-Path $cxx)) {
  throw "x64 compiler not found under $binDir"
}

$env:Path = "$binDir;$env:Path"
$dumpMachine = (& $cc -dumpmachine).Trim()
if ($Arch -eq "X64" -and $dumpMachine -notmatch "x86_64") {
  throw "selected compiler is not x64: $dumpMachine"
}

$wsize = "32"
if ($Arch -eq "X64") {
  $wsize = "64"
}
$multi = ""
if ($MultiMode -eq "AUTO") {
  if ($Cores -gt 1) {
    $multi = "OPENMP"
  }
} elseif ($MultiMode -eq "OPENMP") {
  $multi = "OPENMP"
} elseif ($MultiMode -eq "PTHREAD") {
  $multi = "PTHREAD"
} else {
  $multi = ""
}

Push-Location $targetDir

if ($CleanConfigure) {
  if (Test-Path (Join-Path $targetDir "CMakeCache.txt")) {
    Remove-Item -Force (Join-Path $targetDir "CMakeCache.txt")
  }
  if (Test-Path (Join-Path $targetDir "CMakeFiles")) {
    Remove-Item -Recurse -Force (Join-Path $targetDir "CMakeFiles")
  }
}

& $cmake -G "MinGW Makefiles" `
  -DCMAKE_BUILD_TYPE=Release `
  "-DCMAKE_C_COMPILER=$cc" `
  "-DCMAKE_CXX_COMPILER=$cxx" `
  "-DARCH=$Arch" `
  "-DWSIZE=$wsize" `
  -DARITH=gmp `
  "-DGMP_ROOT=$ToolchainRoot" `
  "-DGMP_INCLUDE_DIR=$ToolchainRoot/include" `
  "-DGMP_LIBRARIES=$ToolchainRoot/lib/libgmp.a" `
  -DFP_PRIME=381 `
  "-DWITH=BN;DV;FP;FPX;EP;EPX;PP;PC;CP;MD" `
  -DSHLIB=off `
  -DSTLIB=on `
  -DSTBIN=on `
  -DCHECK=off `
  -DVERBS=off `
  -DDOCUM=off `
  -DQUIET=on `
  -DTESTS=0 `
  -DBENCH=0 `
  "-DCORES=$Cores" `
  "-DMULTI=$multi" `
  "-DCFLAGS=-O3 -funroll-loops -fomit-frame-pointer -finline-small-functions" `
  ../../..
if ($LASTEXITCODE -ne 0) {
  throw "relic cmake configure failed"
}

& $cmake --build . --target relic_s -j
if ($LASTEXITCODE -ne 0) {
  throw "relic build failed"
}

Pop-Location

Write-Output "relic rebuilt for UPSI: $targetDir"
