param(
  [ValidateSet("quick", "target")]
  [string]$Profile = "quick",
  [int]$Trials = 1,
  [ValidateSet(0,1)]
  [int]$RobustMode = 0,
  [int]$BucketThreads = 1,
  [int]$MaxPoints = 0,
  [ValidateSet("Release", "RelWithDebInfo", "Debug")]
  [string]$BuildType = "Release",
  [switch]$ParallelPoints = $false,
  [switch]$UseX64Toolchain = $true,
  [string]$ToolchainRoot = "C:\Users\chico\Documents\Codex\upsi\toolchains\winlibs-x64\mingw64"
)

$ErrorActionPreference = "Stop"

$cmake = "cmake"
$repoCmake = "C:\Users\chico\Documents\Codex\upsi\alos22\tools\cmake-3.31.11-windows-x86_64\bin\cmake.exe"
if (Test-Path $repoCmake) {
  $cmake = $repoCmake
}

$root = "C:\Users\chico\Documents\Codex\upsi\upsi_imp"
$buildDir = Join-Path $root "build"
$cc = ""
$cxx = ""
if ($UseX64Toolchain) {
  $binDir = Join-Path $ToolchainRoot "bin"
  $cc = Join-Path $binDir "gcc.exe"
  $cxx = Join-Path $binDir "g++.exe"
  if (!(Test-Path $cc) -or !(Test-Path $cxx)) {
    throw "x64 toolchain not found: $binDir"
  }
  $env:Path = "$binDir;$env:Path"
  $mach = (& $cc -dumpmachine).Trim()
  if ($mach -notmatch "x86_64") {
    throw "selected compiler is not x64: $mach"
  }
  $buildDir = Join-Path $root "build_x64"
}
$outDir = Join-Path $root "experiment_results"
$outCsv = Join-Path $outDir "upsi_4_3_2_summary.csv"

New-Item -ItemType Directory -Force -Path $buildDir | Out-Null
New-Item -ItemType Directory -Force -Path $outDir | Out-Null

Push-Location $buildDir

if ($UseX64Toolchain) {
  & $cmake -G "MinGW Makefiles" "-DCMAKE_BUILD_TYPE=$BuildType" "-DCMAKE_C_COMPILER=$cc" "-DCMAKE_CXX_COMPILER=$cxx" ..
} else {
  & $cmake -G "MinGW Makefiles" "-DCMAKE_BUILD_TYPE=$BuildType" ..
}
if ($LASTEXITCODE -ne 0) {
  throw "cmake configure failed"
}

& $cmake --build . --target upsi_exp_4_3_2_bench -j
if ($LASTEXITCODE -ne 0) {
  throw "build benchmark failed"
}

if (-not $ParallelPoints) {
  if ($RobustMode -ne 0) {
    .\upsi_exp_4_3_2_bench.exe $outCsv $Profile $Trials 1 $MaxPoints 0 0 $BucketThreads
  } else {
    .\upsi_exp_4_3_2_bench.exe $outCsv $Profile $Trials 0 $MaxPoints 0 0 $BucketThreads
  }
  if ($LASTEXITCODE -ne 0) {
    throw "benchmark run failed"
  }
} else {
  $allPoints = @()
  if ($Profile -eq "quick") {
    $allPoints = @(128, 256, 512, 1024)
  } else {
    $allPoints = @(16384, 65536, 262144)
  }

  if ($MaxPoints -gt 0) {
    $take = [Math]::Min($MaxPoints, $allPoints.Count)
    if ($take -le 0) {
      throw "invalid MaxPoints"
    }
    $allPoints = $allPoints[0..($take - 1)]
  }

  $robustArg = if ($RobustMode -ne 0) { "1" } else { "0" }
  $jobs = @()
  foreach ($n in $allPoints) {
    $pointCsv = Join-Path $outDir ("upsi_4_3_2_n{0}.csv" -f $n)
    $args = @($pointCsv, $Profile, $Trials, $robustArg, 1, $n, 0, $BucketThreads)
    $p = Start-Process -FilePath ".\upsi_exp_4_3_2_bench.exe" -ArgumentList $args -PassThru
    $jobs += [PSCustomObject]@{ N = $n; Csv = $pointCsv; Proc = $p }
  }

  foreach ($j in $jobs) {
    $j.Proc.WaitForExit()
    if ($j.Proc.ExitCode -ne 0) {
      throw ("benchmark run failed for n={0} (exit={1})" -f $j.N, $j.Proc.ExitCode)
    }
  }

  $merged = @()
  $headerWritten = $false
  foreach ($j in ($jobs | Sort-Object N)) {
    if (-not (Test-Path $j.Csv)) {
      throw ("missing result file for n={0}: {1}" -f $j.N, $j.Csv)
    }
    $lines = Get-Content $j.Csv
    if ($lines.Count -eq 0) {
      throw ("empty result file for n={0}: {1}" -f $j.N, $j.Csv)
    }
    if (-not $headerWritten) {
      $merged += $lines[0]
      $headerWritten = $true
    }
    if ($lines.Count -gt 1) {
      $merged += $lines[1..($lines.Count - 1)]
    }
  }
  Set-Content -Path $outCsv -Value $merged -Encoding UTF8
}

Pop-Location
Write-Output "benchmark result: $outCsv"
