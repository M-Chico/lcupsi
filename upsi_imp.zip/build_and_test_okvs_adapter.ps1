$ErrorActionPreference = "Stop"

$cmake = "cmake"
$repoCmake = "C:\Users\chico\Documents\Codex\upsi\alos22\tools\cmake-3.31.11-windows-x86_64\bin\cmake.exe"
if (Test-Path $repoCmake) {
  $cmake = $repoCmake
}

New-Item -ItemType Directory -Force -Path build | Out-Null
Push-Location build

& $cmake -G "MinGW Makefiles" ..
if ($LASTEXITCODE -ne 0) {
  throw "cmake configure failed"
}

& $cmake --build . --target test_okvs_blocksplit test_bucketization test_okvs_small_n_calibration test_okvs_param_policy test_pbpsi_m1 test_relic_bridge_consistency test_initial_round_small test_delta_round_small -j
if ($LASTEXITCODE -ne 0) {
  throw "build failed"
}

.\test_okvs_blocksplit.exe
if ($LASTEXITCODE -ne 0) {
  throw "test failed"
}

.\test_bucketization.exe
if ($LASTEXITCODE -ne 0) {
  throw "bucket test failed"
}

.\test_okvs_small_n_calibration.exe
if ($LASTEXITCODE -ne 0) {
  throw "okvs calibration test failed"
}

.\test_okvs_param_policy.exe
if ($LASTEXITCODE -ne 0) {
  throw "okvs param policy test failed"
}

if (Test-Path ".\test_pbpsi_m1.exe") {
  .\test_pbpsi_m1.exe
  if ($LASTEXITCODE -ne 0) {
    throw "pbpsi m=1 test failed"
  }
}

if (Test-Path ".\test_relic_bridge_consistency.exe") {
  .\test_relic_bridge_consistency.exe
  if ($LASTEXITCODE -ne 0) {
    throw "relic bridge consistency test failed"
  }
}

if (Test-Path ".\test_initial_round_small.exe") {
  .\test_initial_round_small.exe
  if ($LASTEXITCODE -ne 0) {
    throw "initial round small test failed"
  }
}

if (Test-Path ".\test_delta_round_small.exe") {
  .\test_delta_round_small.exe
  if ($LASTEXITCODE -ne 0) {
    throw "update round small test failed"
  }
}

Pop-Location
