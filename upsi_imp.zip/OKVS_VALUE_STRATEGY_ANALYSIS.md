# OKVS value strategy analysis for UPSI

## Problem statement

In LcUPSI, OKVS stores payload `c_y || V_y`.

- `c_y`: compressed group element (about 49 bytes in our RELIC/BLS12-381 build).
- `V_y`: verification tag hash (typically 32 bytes with SHA-256).

So payload is around 81 bytes, much larger than current OKVS value type (`uint128_t`, 16 bytes).

## Candidate A: multi-table block split (current implementation path)

Idea:
- Split one payload into `K = ceil(payload_bytes / 16)` blocks.
- Encode each block in one OKVS table with the same keys.
- Decode all `K` tables and reassemble payload.

Correctness impact:
- No protocol-level behavior change.
- Equivalent to solving the same linear system with vector-valued RHS.
- Pairing check and intersection logic are unchanged.

Security impact:
- No additional leakage if key set and payload semantics are unchanged.
- Non-key decode remains pseudo-random per block; final acceptance still gated by `V_y` check.

Cost impact:
- Encode/decode cost scales by about `K`.
- Communication scales by `16 * K` bytes per encoded item (payload rounded to 16-byte boundary).
- For 81-byte payload, `K=6` (96 bytes effective), about 18.5% padding overhead.
- Practical note from local test: current OKVS parameter sets are sensitive to small `n`.
  We observed stable zero-mismatch on the validated baseline (`n=2^12, w=360, e=1.12`).

Engineering impact:
- Lowest integration risk.
- Works now with the existing tested OKVS code.

Empirical calibration summary (payload = 81 bytes, 3 trials each):

- `n=32`: `w=8, e=1.75`
- `n=64`: `w=12, e=1.35`
- `n=128`: `w=16, e=1.25`
- `n=256`: `w=24, e=1.18`
- `n=512..2048`: `w=24, e=1.12`
- `n=4096`: `w=48, e=1.12`

## Candidate B: "stretch value" inside one OKVS

Idea:
- Modify OKVS value type from `uint128_t` to fixed-width byte vector / block vector.

Correctness and security:
- Can be made equivalent to Candidate A.

Cost:
- Same communication size as Candidate A unless bit-level packing is added.
- Compute may be lower than A if elimination matrix is shared once and applied to multi-block RHS.

Engineering risk:
- Requires invasive OKVS core modifications and re-validation.
- Higher bug risk in near-term UPSI implementation.

## Candidate C: shorten `(c_y || V_y)`

### C1) shorten `c_y`

Not recommended:
- `c_y` is needed directly in pairing verification `e(c_y, W)`.
- Strong compression below group compressed form is not straightforward and may break correctness.

### C2) shorten `V_y`

Possible with explicit tradeoff:
- Use truncated hash tag, e.g. 16 bytes (128-bit).
- False accept probability per trial becomes `2^-128`.
- For realistic trial counts, still negligible.

This can reduce payload from 81 to 65 bytes (`K=5`, 80 bytes after block rounding), improving communication.

Risk:
- Deviates from "full SHA-256 tag" wording in paper-level presentation.
- Must document security parameter as 128-bit tag, and keep consistent across both parties.

## Recommended phased decision

1. **Now**: use Candidate A (multi-table split), keep full `V_y` length.
2. **After end-to-end UPSI is stable**: optionally evaluate C2 (`V_y` truncation to 16 bytes).
3. **Optimization stage**: if needed, implement Candidate B to reduce CPU (shared elimination), while keeping wire format unchanged.

This path minimizes implementation risk and does not change protocol logic.
