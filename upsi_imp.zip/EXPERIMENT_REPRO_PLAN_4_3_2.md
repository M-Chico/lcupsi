# UPSI 4.3.2 experiment reproduction plan (small-dataset-first)

## Goal alignment

Your requirement is:

1. Reproduce the UPSI experiment section you refer to as 4.3.2.
2. Bucket-level data size does **not** need to be as large as `2^12`.
3. Start all validation from small datasets, then scale.

This plan follows those constraints.

## 4.3.2 target profile (updated per your requirement)

For your target experiment, use:

- set sizes: `|X|=|Y| in {2^14, 2^16, 2^18}`
- bucket count: `b = n / 2^7` (thus `2^7, 2^9, 2^11`)
- expected per-bucket occupancy: around `2^7`
- reserved per-bucket slack: `+128` logical slots (for update tolerance)
- update sizes: `|ΔY| in {2^3, 2^7}` (`2^5` skipped)
- each `(n, |ΔY|)` group runs once (`Trials=1`)

Implemented in benchmark profile `target`:

- executable: `upsi_exp_4_3_2_bench`
- runner: `run_exp_4_3_2.ps1`

## Key adjustment from previous path

We no longer assume a single fixed OKVS parameter set (`n=2^12, w=360, e=1.12`) for every bucket.
Instead:

1. Use per-bucket adaptive OKVS parameters.
2. For tiny buckets, pad to a minimum stable size before encoding.
3. Keep protocol logic unchanged (same pairing verification and intersection semantics).

## Calibrated OKVS profile (payload bytes = 81)

From local calibration (`test_okvs_small_n_calibration`):

- `n<=32`: `w=8, e=1.75`
- `33..64`: `w=12, e=1.35`
- `65..128`: `w=16, e=1.25`
- `129..256`: `w=24, e=1.18`
- `257..2048`: `w=24, e=1.12`
- `2049..4096`: `w=48, e=1.12`

Policy implementation:

- [upsi_okvs_param_policy.h](C:/Users/chico/Documents/Codex/upsi/upsi_imp/include/upsi_okvs_param_policy.h)

Small-bucket rule:

- if bucket size `< 32`, pad with random dummy entries to `32` before OKVS encoding.
- decode/verify keeps only elements that pass pairing+tag checks, so dummies are filtered out.

## Execution steps (re-analyzed for your experiment objective)

### Step 1: complete initial round in `upsi_imp` with adaptive-bucket OKVS

Implement in this order:

1. bucketization (`H_B`) and per-bucket state.
2. per-bucket `EncryptSet/GetWitness` wrapper (ALOS22 primitive mapping).
3. per-bucket signer output `(c_y, V_y)`.
4. OKVS encode/decode via block-split adapter with adaptive params.
5. evaluate pairing and collect `Z`.

Validation:

- Tiny sets first (`|X|,|Y|` in 64..256), then 512, 1024.
- Compare output with naive intersection every run.

### Step 2: complete update rounds with `flag` and cache reuse

Implement update-round mechanics:

1. apply `X+`, `X-`, `Y+`, `Y-` by bucket.
2. generate `flag[i]` for changed buckets.
3. changed bucket: recompute ciphertext/witness.
4. unchanged bucket: rerandomize cached ciphertext/witness.
5. `P1` computes `I1` (stable old-intersection) + `I2` (new checks).
6. final `I_upd = I1 union I2`.

Validation:

- Start with tiny updates (add/del sizes 1..8), then 16..64.
- Run multi-round random simulation and compare with naive baseline each round.

### Step 3: build experiment harness for target section metrics

Add a dedicated benchmark runner producing:

1. total runtime,
2. `P1` online runtime,
3. communication bytes,
4. update-state setup runtime (separate from pure update runtime).

Process:

1. first run small-scale matrix (fast iteration, correctness gate).
2. then run target section scale matrix.
3. for each config run 3 times and take median.

### Step 4: lock experiment profile and output format

Before full runs:

1. freeze random seeds and parameter file,
2. freeze bucket strategy and OKVS policy,
3. log all parameters in each output record for reproducibility.

## Immediate next implementation task

Next coding task should be:

1. create `upsi_protocol_initial` module using current bucket + okvs adapter + param policy.
2. add `test_initial_round_small.cpp`:
   - start from `(64,64)`,
   - then `(128,128)`,
   - then `(256,256)`.
3. require exact equality to naive intersection before moving to update rounds.

## Current acceleration and measurement status

### A. Release build is now enforced

- `run_exp_4_3_2.ps1` passes `-DCMAKE_BUILD_TYPE=Release`.
- `CMakeLists.txt` sets `Release` as default for single-config generators.

This keeps local UPSI/OKVS code optimized (`-O3 -DNDEBUG`).

### B. Update timing is now split clearly

Benchmark CSV adds `median_setup_ms`:

- for `initial` rows: `median_setup_ms=0`
- for `update` rows: `median_setup_ms` is measured from `InitializeUpdateState(...)`
- `median_total_ms` in `update` remains pure `RunUpdateRoundWithStats(...)` time

This avoids mixing initialization cost into update execution cost.

### C. Safe parallel mode for experiment points

`run_exp_4_3_2.ps1` supports `-ParallelPoints`:

- parallelizes different `n` points as separate processes
- merges per-point CSV outputs into `upsi_4_3_2_summary.csv`
- protocol logic per process is unchanged

Why process-level parallel (not in-protocol threading):

- current RELIC config is single-thread style (`CORES=1`, `MULTI` undefined), so bucket-level in-process parallelism is unsafe without rebuilding RELIC thread mode.

### D. Current default run profile

`run_exp_4_3_2.ps1` defaults are now:

- `Trials=1`
- `RobustMode=false`

Implementation note:

- non-robust mode still performs a lightweight OKVS consistency check on real keys
- and allows a single stronger-parameter fallback for correctness
- strict robust mode (`RobustMode=true`) keeps multi-level retry behavior

## Recommended run commands

Sequential baseline:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\chico\Documents\Codex\upsi\upsi_imp\run_exp_4_3_2.ps1 -Profile target -Trials 1 -RobustMode 0 -BuildType Release -UseX64Toolchain
```

Parallel points:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\chico\Documents\Codex\upsi\upsi_imp\run_exp_4_3_2.ps1 -Profile target -Trials 1 -RobustMode 0 -BuildType Release -UseX64Toolchain -ParallelPoints
```

## RELIC rebuild (current best effort in this environment)

Use x64 WinLibs toolchain (recommended):

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\chico\Documents\Codex\upsi\upsi_imp\setup_winlibs_x64_toolchain.ps1
```

Then rebuild RELIC in 64-bit mode:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\chico\Documents\Codex\upsi\upsi_imp\rebuild_relic_for_upsi.ps1 -Arch X64 -Cores 1
```

Applied tuning:

- `Release`, `-O3` class C flags
- `QUIET=on` (suppress heavy error-print overhead in decode-reject path)
- reduced module set to protocol-required core (`BN,DV,FP,FPX,EP,EPX,PP,PC,CP,MD`)
- static library only

Notes:

- this path keeps `ARITH=gmp` by injecting GMP dev files into the x64 toolchain.
- `CORES>1` enables OpenMP in RELIC, but current UPSI workload measured slower on this machine; keep `Cores=1` as default.

## New metrics fields for 4.3.2 outputs

CSV now includes per-round decomposition:

- phase time: `bucketize`, `delta_apply`, `unchanged_filter`, `sort_unique`,
  `relic_init`, `relic_clean`, `eval_total`
- internal eval time: `p0_bucket_create`, `p1_sign`, `p1_okvs_encode`,
  `p0_okvs_decode`, `p0_verify`
- communication split: `p0->p1_ci`, `p1->p0_okvs`, `p0->p1_result`, `p0->p1_flag`
- robust behavior: `okvs_encode_attempts`, `okvs_self_checks` (+full/sampled)
- bucket occupancy for both parties: `x_bucket_min/max`, `y_bucket_min/max`
- per-element performance: `p1_sign_us_per_item`, `p0_verify_us_per_item`

`median_p1_online_ms` now follows your definition:

- from receiving the first `Ci` in the round
- to receiving the last result message from `P0` in the same round.
