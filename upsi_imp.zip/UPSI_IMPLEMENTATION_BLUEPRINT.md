# UPSI on ALOS22: analysis and implementation blueprint

## 1) What exists today (ALOS22 baseline)

Current runnable baseline is in:

- `C:\Users\chico\Documents\Codex\upsi\alos22\relic-main\demo\psi-client-server\sender.c`
- `C:\Users\chico\Documents\Codex\upsi\alos22\relic-main\demo\psi-client-server\receiver.c`
- `C:\Users\chico\Documents\Codex\upsi\alos22\relic-main\src\cp\relic_cp_pbpsi.c`

The core ALOS22 primitives are:

- `cp_pbpsi_ask(...)`: build one ciphertext plus witnesses from one set.
- `cp_pbpsi_ans(...)`: sign responder elements against that ciphertext.
- `cp_pbpsi_int(...)`: pairing check and intersection extraction.

So the current code is "single big set -> one ciphertext/witness family", without bucket-level incremental updates and without OKVS.

## 2) What LcUPSI adds over ALOS22 (paper 3.2)

From section 3.2, improvements are:

1. **Bucketization**
- Both parties hash elements into `b` buckets via `H_B`.
- Run ALOS22-style encrypt/sign/check per bucket instead of global set.

2. **Initial-round structure**
- `P0` computes per-bucket ciphertext `C_i` and witness `W_i,j`.
- `P1` computes per-element signed tuple `(c_{y}, V_{y})`, where:
  - `c_y` is group element related to `(k - y)` and randomizer `s`.
  - `V_y = H1(pairing(..., C_i))`.

3. **OKVS compression**
- `P1` encodes key-value pairs keyed by `H2(y)` into per-bucket OKVS table `T_i`.
- `P0` decodes by `H2(x)` and verifies by pairing equation.

4. **Result transport**
- `P0` returns matched hashed keys `Z`; `P1` maps back to intersection.

## 3) What LcUPSI adds over ALOS22 (paper 3.3 update rounds)

From section 3.3, update round adds:

1. **Delta inputs**
- `P0`: add set `X+`, delete set `X-`.
- `P1`: add set `Y+`, delete set `Y-`.

2. **Flagged bucket update**
- Maintain bucket arrays across rounds.
- If bucket changed: recompute ciphertext/witness from scratch.
- If bucket unchanged: re-randomize old ciphertext/witness (no full recompute).
- Emit `flag[i]` for changed buckets.

3. **P1 split logic**
- Keep stable old-intersection part in `I1` when `flag[i]==0`.
- For changed buckets (`flag[i]==1`): build new OKVS tables.
- For specific added elements in unchanged buckets: send compact direct items (`eY`) for pairing checks.

4. **Final updated intersection**
- `I_upd = I1 union I2`, where `I2` comes from current pairing+decode results.

## 4) Key engineering decisions for our code

### A) Language and linkage

- Keep all new UPSI code in `upsi_imp`.
- Use **C++17** as primary language (OKVS is already C++).
- Call RELIC C APIs via `extern "C"` where needed.

### B) OKVS value width mismatch

Current standalone OKVS (`okvs_standalone`) value type is `uint128_t`.
But LcUPSI payload value is `c_y || V_y` (much larger than 128 bits).

Chosen solution (phase-1 safe path):

- Serialize payload bytes (`c_y` compressed bytes + `V_y` bytes).
- Split into `K` 128-bit blocks.
- Build `K` parallel OKVS tables per bucket (same keys, per-block value).
- Decode all `K` tables and reassemble payload.

Reason:

- protocol-equivalent to wide-value OKVS,
- minimal invasive changes to proven OKVS code,
- can be upgraded later to single-pass multi-block elimination for speed without changing wire semantics.

### C) Hash discipline

- `H_B`: bucket index hash (deterministic, shared seed).
- `H2`: OKVS key hash -> fixed 128-bit key.
- `H1`: verification hash (same digest function and byte format on both sides).

Use strict domain separation tags to avoid cross-hash misuse.

### D) Stateful update engine

Need persistent protocol state:

- per-bucket elements,
- per-bucket ciphertext/witness cache,
- previous intersection hashes (`I_old`),
- current round flags and delta metadata.

## 5) Target layout under `upsi_imp`

Recommended structure:

- `upsi_imp/CMakeLists.txt`
- `upsi_imp/include/upsi_types.h`
- `upsi_imp/include/upsi_hash.h`
- `upsi_imp/include/upsi_bucket.h`
- `upsi_imp/include/upsi_okvs_adapter.h`
- `upsi_imp/include/upsi_protocol.h`
- `upsi_imp/include/upsi_wire.h`
- `upsi_imp/src/upsi_hash.cpp`
- `upsi_imp/src/upsi_bucket.cpp`
- `upsi_imp/src/upsi_okvs_adapter.cpp`
- `upsi_imp/src/upsi_protocol_initial.cpp`
- `upsi_imp/src/upsi_protocol_update.cpp`
- `upsi_imp/src/upsi_sender_main.cpp`
- `upsi_imp/src/upsi_receiver_main.cpp`
- `upsi_imp/third_party/okvs/*` (copied/minimized from `okvs_standalone`)
- `upsi_imp/tests/test_initial_round.cpp`
- `upsi_imp/tests/test_update_round.cpp`
- `upsi_imp/tests/test_okvs_payload_split.cpp`

## 6) Phased implementation plan

### Phase 0: bootstrap

- Create build system and compile RELIC + OKVS together.
- Add small deterministic test harness (single process).

Acceptance:
- Can call `cp_pbpsi_ask/ans/int` from `upsi_imp` executable.
- Can call OKVS encode/decode from same executable.

### Phase 1: initial round without OKVS

- Implement bucketization + per-bucket pairing flow.
- Use direct vector map instead of OKVS first (for correctness baseline).

Acceptance:
- Initial-round intersection equals naive set intersection.

### Phase 2: plug in OKVS

- Implement payload split/merge (`c_y || V_y` <-> Kx128 blocks).
- Replace direct map with per-bucket multi-table OKVS.

Acceptance:
- Same correctness as Phase 1.
- Byte-level encode/decode roundtrip test passes.

### Phase 3: update rounds

- Add stateful bucket cache and `flag`.
- Changed bucket recompute + unchanged bucket rerandomization.
- Implement `I1`, `I2`, and final `I_upd`.

Acceptance:
- Multi-round random simulation equals naive update-intersection baseline.

### Phase 4: socket protocol

- Move from local simulation to sender/receiver processes in `upsi_imp`.
- Define versioned message formats for:
  - setup/params,
  - bucket ciphertext updates,
  - flags,
  - OKVS tables,
  - `eY`,
  - `Z`.

Acceptance:
- End-to-end two-process run succeeds for initial + multiple update rounds.

### Phase 5: benchmark and hardening

- Add timing and communication counters.
- Compare against existing `alos22` demo and tuned parameters (`b`, bucket load).

Acceptance:
- Reproducible benchmark script and result logs.

## 7) Immediate next coding step

Start with **Phase 0 + Phase 1 scaffold** in `upsi_imp`:

- build files,
- shared data model,
- bucketed initial round (direct map first),
- deterministic smoke tests.

Then we plug OKVS (Phase 2) with low risk because protocol correctness is already isolated.

## 8) Function-level mapping (ALOS22 -> UPSI modules)

Direct mapping to avoid ambiguity during coding:

- `EncryptSet(X_i, ...)` (paper 3.2) -> wrapper around `cp_pbpsi_ask(...)` for one bucket.
  - output mapping:
    - `d[0]` -> bucket ciphertext `C_i`
    - `d[j+1]` -> witness `W_i,j`
- `Sign elements` (paper 3.2) -> wrapper around `cp_pbpsi_ans(...)` for one bucket.
  - output mapping:
    - `u[j]` -> `c_y` candidate payload field
    - `t[j]` -> derive `V_y = H1(t[j] bytes)`
- `Evaluate pairing` (paper 3.2/3.3) -> adapted `cp_pbpsi_int(...)` logic
  - but inputs come from OKVS-decoded payloads (or `eY`) instead of flat arrays.

Update-round specific mapping:

- unchanged bucket rerandomization:
  - `C_i' = C_i ^ r_i` and `W_i,j' = W_i,j ^ r_i` (group scalar multiplication form).
- changed bucket:
  - rerun per-bucket `EncryptSet + GetWitness`.
- `flag[i]`:
  - stored in protocol state and sent in wire message for P1 branch logic.
